#include <genesis.h>

int main()
{

    while(1)
    {
        SYS_doVBlankProcess();
    }
    return (0);
}
